# PassiveCore-Dashboard

This repository contains scripts, templates, and automations for the Passive Core master dashboard system.

## Structure

- `scripts/`: Automation scripts for bots, sync, and dashboard tasks
- `docs/`: System blueprints and documentation
- `dashboard-template.xlsx`: Template for setting up the Google Sheets dashboard
